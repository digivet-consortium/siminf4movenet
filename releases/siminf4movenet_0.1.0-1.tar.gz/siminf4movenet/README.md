# siminf4movenet
a (possibly temporary) R package for the siminf model previously within the movenet package
