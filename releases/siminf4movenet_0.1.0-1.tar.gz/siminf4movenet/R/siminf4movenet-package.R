#' @name siminf4movenet-package
#' @aliases siminf4movenet
#' @title What the Package Does (One Line, Title Case)
#'
#' @details
#' Some description of the package
#'
#'
#' ## To cite this package in publications use:
#' citation("siminf4movenet")
#'
#' @seealso
#' \code{\link[movenet]{movedata2networkDynamic}} for something in movenet
#'
#' @references
#' Some article that you might want users to look at
#'
#' @keywords internal
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
NULL
